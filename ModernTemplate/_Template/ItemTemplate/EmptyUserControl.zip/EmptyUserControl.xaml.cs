﻿//-----------------------------------------------------------------------
// <copyright file="$safeitemname$.xaml.cs" company="$Company$">
//     Class: $safeitemname$
//     Copyright © $Company$ $year$
// </copyright>
//
// <author>$Author$ - $Company$</author>
// <email>$Email$</email>
// <date>$time$</date>
//
// <TemplateVersion>$Templateversion$</TemplateVersion>
//
// <summary>
// Beispiel UserControl mit Basisfunktionen des ModernUI Framework
// </summary>
//-----------------------------------------------------------------------

namespace $rootnamespace$
{
    using System.Windows;
    using System.Windows.Controls;
    using ModernTemplate.Core;

    using ModernUI.MVVM.Base;

    /// <summary>
    /// Interaktionslogik für $safeitemname$.xaml
    /// </summary>
    public partial class $safeitemname$ : UserControlBase
    {
        public $safeitemname$() : base(typeof($safeitemname$))
        {
            this.InitializeComponent();
            WeakEventManager<UserControl, RoutedEventArgs>.AddHandler(this, "Loaded", this.OnLoaded);
            WeakEventManager<UserControl, RoutedEventArgs>.AddHandler(this, "Unloaded", this.OnUnloaded);

            this.InitCommands();
            this.DataContext = this;
        }

        #region Properties
        #endregion Properties

        public override void InitCommands()
        {
            /* Eventuelle Behandlung von Commands */
        }

        private void OnLoaded(object sender, RoutedEventArgs e)
        {
            /* Aktion wenn das UserControl geladen wird */
        }

        private void OnUnloaded(object sender, RoutedEventArgs e)
        {
            /* Aktion wenn das UserControl verlassen wird */
        }
    }
}
