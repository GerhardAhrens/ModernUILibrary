﻿//-----------------------------------------------------------------------
// <copyright file="$safeitemname$.xaml.cs" company="$Company$">
//     Class: $safeitemname$
//     Copyright © $Company$ $year$
// </copyright>
//
// <author>$Author$ - $Company$</author>
// <email>$Email$</email>
// <date>$time$</date>
//
// <TemplateVersion>Templateversion</TemplateVersion>
//
// <summary>
// Beispiel UI Dialog mit einem 'Back'-Button
// </summary>
//-----------------------------------------------------------------------

namespace $rootnamespace$
{
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Data;
    using System.Windows.Input;
    using System.Windows.Media;
    using System.Windows.Threading;

    using ModernBaseLibrary.Collection;
    using ModernBaseLibrary.Extension;

    using ModernTemplate.Core;

    using ModernUI.MVVM.Base;

    /// <summary>
    /// Interaktionslogik für CustomUC.xaml
    /// </summary>
    public partial class $safeitemname$ : UserControlBase
    {
        public $safeitemname$() : base(typeof($safeitemname$))
        {
            this.InitializeComponent();
            this.InitCommands();

            WeakEventManager<UserControl, RoutedEventArgs>.AddHandler(this, "Loaded", this.OnLoaded);
            WeakEventManager<UserControl, RoutedEventArgs>.AddHandler(this, "Unloaded", this.OnUnloaded);
            WeakEventManager<UserControl, MouseWheelEventArgs>.AddHandler(this, "PreviewMouseWheel", this.OnPreviewMouseWheel);
        }

        #region Properties
        public string DemoText
        {
            get => base.GetValue<string>();
            set => base.SetValue(value);
        }

        #region InputValidation List
        public ObservableDictionary<string, string> ValidationErrors
        {
            get => base.GetValue<ObservableDictionary<string, string>>();
            set => base.SetValue(value);
        }

        public string ValidationErrorsSelected
        {
            get => base.GetValue<string>();
            set => base.SetValue(value, this.InputNavigationProperty);
        }
        #endregion InputValidation List

        #endregion Properties

        public override void InitCommands()
        {
            this.CmdAgg.AddOrSetCommand(CommandButtons.DialogBack, new RelayCommand(this.DialogBackHandler));
        }

        private void LoadDataHandler()
        {
            /* lesen und vorbereiten von Daten */
        }

        #region WindowEventHandler
        private void OnLoaded(object sender, RoutedEventArgs e)
        {
            this.Focus();
            Keyboard.Focus(this);

            this.RegisterValidations();
            this.LoadDataHandler();

            this.IsUCLoaded = true;
            this.DataContext = this;

            this.DemoText = string.Empty;
        }

		private void OnUnloaded(object sender, RoutedEventArgs e)
        {
            /* Aktion wenn das UserControl verlassen wird */
        }

        private void OnPreviewMouseWheel(object sender, MouseWheelEventArgs e)
        {
            if (Keyboard.IsKeyDown(Key.LeftCtrl) == true)
            {
                if (e.Delta > 0)
                {
                    if (this.Scalefactor.ScaleX <= 2.0)
                    {
                        this.Scalefactor.ScaleX = this.Scalefactor.ScaleX + 0.25;
                        this.Scalefactor.ScaleY = this.Scalefactor.ScaleY + 0.25;
                    }
                }

                if (e.Delta < 0)
                {
                    if (this.Scalefactor.ScaleX > 1.0)
                    {
                        this.Scalefactor.ScaleX = this.Scalefactor.ScaleX - 0.25;
                        this.Scalefactor.ScaleY = this.Scalefactor.ScaleY - 0.25;
                    }
                }
            }
        }

        #endregion WindowEventHandler

        #region Register Validations
        private void RegisterValidations()
        {
            /* Validierungsregeln für 
            this.ValidationRules.Add(nameof(this.Titel), () =>
            {
                return ValidationRule<$safeitemname$>.This(this).NotEmpty(x => x.Titel, "Titel");
            });
            */

        }
        #endregion Register Validations

        #region InputValidation Handler
        private void InputNavigationProperty<T>(T value, string propertyName)
        {
            /* Zu prüfende Eingaben, Background auf Transparent setzten */

            if (value == null)
            {
                return;
            }

            foreach (var ctrl in this.GetChildren())
            {
                /* Gegebenenfalls Eingabe anpassen bzw. erweitern, z.B. CheckBox usw. */
                if (ctrl is TextBox textBox)
                {
                    Binding binding = BindingOperations.GetBinding(textBox, TextBox.TextProperty);
                    if (value != null)
                    {
                        if (binding != null && binding.Path.Path.EndsWith(value.ToString()))
                        {
                            this.Dispatcher.BeginInvoke(DispatcherPriority.Input, new Action(() =>
                            {
                                textBox.Focus();
                                textBox.Background = Brushes.Coral;
                            }));

                            break;
                        }
                    }
                }
            }
        }
        #endregion InputValidation Handler

        #region CommandHandler
        private void DialogBackHandler(object p1)
        {
            if (ValidationErrors.Count > 0)
            {
                /* 
                 * Eventuelle Prüfung, ob Validation Errors vorhanden sind 
                 * Meldung ausgeben, oder andere Behandlung
                 */
            }

            base.EventAgg.Publish<ChangeViewEventArgs>(new ChangeViewEventArgs
            {
                Sender = this.GetType().Name,
                MenuButton = CommandButtons.Home,
                FromPage = CommandButtons.Custom
            });
        }
        #endregion CommandHandler
    }
}
